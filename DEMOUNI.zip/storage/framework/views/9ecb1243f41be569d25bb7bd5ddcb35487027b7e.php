<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class=" col-3 mx-auto my-2">
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
    <?php if($message=Session::get('success_message')): ?>
        <div class="col-3  mx-auto my-2">
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong><?php echo e($message); ?></strong>
            </div>
        </div>
    <?php endif; ?>
    <div class="container m-3 mx-auto ">
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Userame</th>
                <th scope="col">Full name</th>
                <th scope="col">Email</th>
                <th scope="col">Profile</th>
            </tr>
            </thead>
            <tbody>
            <?php while(($p = oci_fetch_object($stid)) != false): ?>
                <tr>
                    <th scope="row"></th>
                    <td><?php echo e($p->USERNAME); ?></td>
                    <td><?php echo e($p->FULL_NAME); ?></td>
                    <td><?php echo e($p->EMAIL); ?></td>
                    <td><?php echo e($p->PROFILE); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('team.o.destroy',$p->ID)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit"  class="btn btn-outline-danger" data-original-title="Delete item" data-toggle="tooltip" style="width:112px;"> × Delete</button>
                        </form>
                    </td>
                    <td>
                        <form method="POST" action="<?php echo e(route('update_data','Team')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden"  name="id" value="<?php echo e($p->ID); ?>">
                            <button type="submit" class="btn btn-outline-success" data-original-title="Update item" data-toggle="tooltip" style="width:112px;"> ! Update</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
            <?php
                oci_free_statement($stid);
                oci_close($conn);
            ?>
            </tbody>
        </table>
        <a href="<?php echo e(route('home')); ?>" type="button" class="btn btn-primary btn-block my-3"> Back</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.headerOracle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wonda\DEMOUNI\resources\views\oracle\teams.blade.php ENDPATH**/ ?>