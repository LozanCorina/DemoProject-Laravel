<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="col-3 mx-auto my-2">
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
    <?php if($message=Session::get('success_message')): ?>
        <div class="col-3  mx-auto my-2">
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong><?php echo e($message); ?></strong>
            </div>
        </div>
    <?php endif; ?>
    <div class="container p-3">
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Asignee</th>
                <th scope="col">Name</th>
                <th scope="col">Description</th>
                <th scope="col">Project</th>
                <th scope="col">Milestone</th>
                <th scope="col">Is complete (Y/N)</th>
                <th scope="col">Date start</th>
                <th scope="col">Date End</th>
            </tr>
            </thead>
            <tbody>
            <?php while(($p = oci_fetch_object($stid)) != false): ?>
                <tr>
                    <th scope="row"></th>
                    <td></td>
                    <td><?php echo e($p->NAME); ?></td>
                    <td><?php echo e($p->DESCRIPTION); ?></td>
                    <td></td>
                    <td></td>
                    <td><?php echo e($p->IS_COMPLETE_YN); ?></td>
                    <td><?php echo e($p->START_DATE); ?></td>
                    <td><?php echo e($p->END_DATE); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('task.o.destroy',$p->ID)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-danger" data-original-title="Delete item" data-toggle="tooltip" style="width:112px;"> × Delete</button>
                        </form>
                    </td>
                    <td>
                        <form method="POST" action="<?php echo e(route('update_data','Task')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden"  name="id" value="<?php echo e($p->ID); ?>">
                            <button type="submit" class="btn btn-outline-success" data-original-title="Update item" data-toggle="tooltip" style="width:112px;"> ! Update</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
            <?php
                oci_free_statement($stid);
                oci_close($conn);
            ?>
            </tbody>
        </table>
        <a href="<?php echo e(route('home')); ?>" type="button" class="btn btn-primary btn-block my-3"> Back</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.headerOracle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wonda\DEMOUNI\resources\views\oracle\tasks.blade.php ENDPATH**/ ?>