

<?php $__env->startSection('content'); ?>   
<?php if($errors->any()): ?>
        <div class="col-3 mx-auto my-2">
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
        </div>
            <?php endif; ?> 
        <?php if($message=Session::get('success_message')): ?>   
            <div class="col-3 mx-auto my-2">
                <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">x</button>
                        <strong><?php echo e($message); ?></strong>
                </div>  
            </div>         
            <?php endif; ?>  
      <div class="container p-3">
        <table class="table table-striped">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Project Id</th>
            <th scope="col">Name</th>
            <th scope="col">Description</th>
            <th scope="col">Due date</th>
            <th scope="col">Created at</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <th scope="row"><?php echo e($p->id); ?></th>
            <td><?php echo e($p->project_id); ?></td>
            <td><?php echo e($p->name); ?></td>
            <td><?php echo e($p->description); ?></td>
            <td><?php echo e($p->due_date); ?></td>
            <td><?php echo e($p->completed_date); ?></td>        
            <td><?php echo e($p->created_at); ?></td>
            <td> 
                <form method="POST" action="<?php echo e(route('mile.destroy',$p->id)); ?>"> 
                <?php echo csrf_field(); ?>                              
                <button type="submit" onclick="return confirm('Are you sure to delete this item?')" class="btn btn-outline-danger" data-original-title="Delete item" data-toggle="tooltip" style="width:112px;"> × Delete</button>
                </form>
            </td>
            <td> 
                <form method="POST" action="<?php echo e(route('update',['model'=>'Milestone'])); ?>"> 
                <?php echo csrf_field(); ?>   
                <input type="hidden"  name="id" value="<?php echo e($p->id); ?>">                           
                <button type="submit" class="btn btn-outline-success" data-original-title="Update item" data-toggle="tooltip" style="width:112px;"> ! Update</button>
                </form>
            </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        </tbody>
        </table>
        <a href="<?php echo e(route('home')); ?>" type="button" class="btn btn-primary btn-block"> Back</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wonda\DEMOUNI\resources\views\milestones.blade.php ENDPATH**/ ?>