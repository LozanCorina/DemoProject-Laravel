<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="col-3 mx-auto my-2">
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
    <?php if($message=Session::get('success_message')): ?>
        <div class="col-3 mx-auto my-2">
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong><?php echo e($message); ?></strong>
            </div>
        </div>
    <?php endif; ?>
    <section class="section-content my-3 ">
        <div class="d-flex justify-content-center ">
            <div class="row">
                <div class="card col-xl-12">
                    <table class="table">
                        <thead>
                            <tr>
                                <?php
                                for ($i = 1; $i <= $ncols; $i++) {
                                    $column_name  = oci_field_name($stid, $i);
                                    echo "<td>$column_name</td>";
                                    }
                                ?>
                            </tr>
                        </thead>
                        <tbody>
                        <?php while(($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS))): ?>
                            <tr>
                                <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <td> <?php echo e($item !== null ? htmlentities($item, ENT_QUOTES) : "&nbsp;"); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.headerOracle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wonda\DEMOUNI\resources\views\oracle\worksheet_result.blade.php ENDPATH**/ ?>