

<?php $__env->startSection('content'); ?> 
<section class="section-content my-3 "> 
    <div class="d-flex justify-content-center ">
        <div class="row">           
            <div class="card col-xl-12">
                <article class="card-body">
                    <form id="f_t" method="POST" action="<?php echo e(route('team.update')); ?>">
                            <?php echo csrf_field(); ?>                            
                         <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
                        <div class="form-group">
                            <label>Username</label>
                            <input name="username" class="form-control" value="<?php echo e($d->username); ?>" type="text">               
                        </div> <!-- form-group// -->
                        <div class="form-group">
                            <label>Full name</label>
                            <input name="full_name" class="form-control" value="<?php echo e($d->full_name); ?>" type="text">               
                        </div> <!-- form-group// -->
                        <div class="form-group">
                            <label>Email</label>
                            <input name="email" class="form-control" value="<?php echo e($d->email); ?>" type="email">               
                        </div> <!-- form-group// -->
                        <div class="form-group">
                            <label>Profile</label>
                            <input name="profile" class="form-control" value="<?php echo e($d->profile); ?>" type="text">               
                        </div> <!-- form-group// -->
                        <div class="form-group">
                            <label>Photo</label>
                                <input class="form-control" name="photo_filename" type="file" value="<?php echo e($d->photo_filename); ?>">              
                        </div> <!-- form-group// -->
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-block my-1"> Update  </button>
                        </div> <!-- form-group// -->                                                           
                    </form>
                </article> <!--card body-->
            </div> <!--end card-->
        </div> <!--end row-->
    </div> <!--container-->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wonda\DEMOUNI\resources\views\update_team.blade.php ENDPATH**/ ?>