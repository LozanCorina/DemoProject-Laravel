<?php $__env->startSection('content'); ?>
    <section class="section-content my-3 ">
        <div class="d-flex justify-content-center ">
            <div class="row">
                <div class="card col-xl-12">
                    <article class="card-body">
                        <form id="f_ta" method="POST" action="<?php echo e(route('data','Task')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php while(($d = oci_fetch_object($stid)) != false): ?>
                            <input type="hidden" name="id" value="<?php echo e($d->ID); ?>">
                            <div class="form-group">
                                <label>Assignee </label>
                                <select name="assignee" class="form-control" type="text">
                                    <option value="<?php echo e($d->ASSIGNEE); ?>" class="text-info" selected><?php echo e($d->ASSIGNEE); ?></option>
                                    <?php
                                        $st = oci_parse($conn, 'SELECT id, username FROM demo_team_members ');
                                        oci_execute($st);
                                    ?>
                                    <?php while(($team = oci_fetch_object($st)) != false): ?>
                                        <option value="<?php echo e($team->ID); ?>" class="text-info"><?php echo e($team->USERNAME); ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div> <!-- form-group// -->
                            <div class="form-group">
                                <label>Name</label>
                                <input name="name" class="form-control" type="text" value="<?php echo e($d->NAME); ?>">
                            </div> <!-- form-group// -->
                            <div class="form-group">
                                <label>Description</label>
                                <input name="description" class="form-control" type="text" value="<?php echo e($d->DESCRIPTION); ?>">
                            </div> <!-- form-group// -->
                            <div class="form-group">
                                <label>Project</label>
                                <select name="project_id" class="form-control" type="text">
                                    <option value="<?php echo e($d->PROJECT_ID); ?>" class="text-info" selected><?php echo e($d->PROJECT_ID); ?></option>
                                    <?php
                                        $st = oci_parse($conn, 'SELECT id, name FROM demo_projects ');
                                        oci_execute($st);
                                    ?>
                                    <?php while(($p = oci_fetch_object($st)) != false): ?>
                                        <option value="<?php echo e($p->ID); ?>" class="text-info"><?php echo e($p->NAME); ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div> <!-- form-group// -->
                            <div class="form-group">
                                <label>Milestone</label>
                                <select name="milestone_id" class="form-control" type="text">
                                    <option value="<?php echo e($d->MILESTONE_ID); ?>" class="text-info" selected><?php echo e($d->MILESTONE_ID); ?></option>
                                    <?php
                                        $st = oci_parse($conn, 'SELECT id, name FROM demo_milestones ');
                                        oci_execute($st);
                                    ?>
                                    <?php while(($p = oci_fetch_object($st)) != false): ?>
                                        <option value="<?php echo e($p->ID); ?>" class="text-info"><?php echo e($p->NAME); ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div> <!-- form-group// -->
                            <div class="form-group">
                                <label>Is complete</label>
                                <select name="is_complete_yn" class="form-control" type="text">
                                    <option value="<?php echo e($d->IS_COMPLETE_YN); ?>" class="text-info" selected><?php echo e($d->IS_COMPLETE_YN); ?></option>
                                    <option value="Y" class="text-info">YES</option>
                                    <option value="N" class="text-info">NO</option>
                                </select>
                            </div> <!-- form-group// -->
                            <div class="form-group">
                                <label>Start date</label>
                                <?php
                                    $date=date_format(date_create($d->START_DATE),'Y-m-d');
                                ?>
                                <input name="start_date" class="form-control" type="date" value="<?php echo e($date); ?>">
                            </div> <!-- form-group// -->
                            <div class="form-group">
                                <label>End date</label>
                                <?php
                                    $date=date_format(date_create($d->END_DATE),'Y-m-d');
                                ?>
                                <input name="end_date" class="form-control" type="date" value="<?php echo e($date); ?>">
                            </div> <!-- form-group// -->
                            <?php endwhile; ?>
                            <?php
                                oci_free_statement($stid);
                                oci_close($conn);
                            ?>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block my-1"> Update  </button>
                            </div> <!-- form-group// -->
                        </form>
                    </article> <!--card body-->
                </div> <!--end card-->
            </div> <!--end row-->
        </div> <!--container-->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.headerOracle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wonda\DEMOUNI\resources\views\oracle\update_task.blade.php ENDPATH**/ ?>