
<?php $__env->startSection('javascript'); ?>
<?php echo $chart->renderChartJsLibrary(); ?>

<?php echo $chart->renderJs(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container my-2">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Chart</div>

                <div class="card-body">

                    <h1><?php echo e($chart->options['chart_title']); ?></h1>
                    <?php echo $chart->renderHtml(); ?>


                </div>
            </div>
        </div>
        <div class="container p-3">
        <table class="table table-striped">
            <h2 clas="title"> My Outstading Tasks</h2>
            <thead>
                <tr>
                <th scope="col">Project</th>
                <th scope="col">Task</th>
                <th scope="col">End Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $prj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>                
                    <td><?php echo e($p->name); ?></td>
                    <td> 
                    <ul>
                    <?php $__currentLoopData = \App\Models\Task::where('project_id',$p->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <?php echo e($n->name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    </td>
                    <td>
                        <ul>
                        <?php $__currentLoopData = \App\Models\Task::where('project_id',$p->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <?php echo e($n->end_date); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>                  
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wonda\DEMOUNI\resources\views\chartLDaily.blade.php ENDPATH**/ ?>