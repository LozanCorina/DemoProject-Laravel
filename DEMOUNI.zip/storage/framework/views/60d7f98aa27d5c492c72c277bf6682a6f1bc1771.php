<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="col-3 mx-auto my-2">
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
    <?php if($message=Session::get('success_message')): ?>
        <div class="col-3 mx-auto my-2">
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong><?php echo e($message); ?></strong>
            </div>
        </div>
    <?php endif; ?>
    <section class="section-content my-3 ">
        <div class="d-flex justify-content-center ">
            <div class="row">
                <div class="card col-xl-12">
                    <article class="card-body">
                        <form action="<?php echo e(route('worksheet.sql')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Worksheet</label>
                                <textarea name="code" class="form-control"  rows="4" cols="50" type="text"></textarea>
                            </div> <!-- form-group// -->
                            <div class="form-group my-1">
                                <button type="submit" class="btn btn-primary btn-block">Run  </button>
                            </div> <!-- form-group// -->
                        </form>
                    </article>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wonda\DEMOUNI\resources\views/sqlWork.blade.php ENDPATH**/ ?>