<?php $__env->startSection('content'); ?>
    <div class="container my-2">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <p>Tabelele disponibile:</p>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <?php
                            $ncols = oci_num_fields($stid);
                                for ($i = 1; $i <= $ncols; $i++) {
                                    $column_name  = oci_field_name($stid, $i);
                                    echo "<td>$column_name</td>";
                                    }
                        ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
                        echo "<tr>\n";
                        foreach ($row as $item) {
                            echo "    <td>" . ($item !== null ? htmlentities($item, ENT_QUOTES) : "&nbsp;") . "</td>\n";
                        }
                        echo "</tr>\n";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.headerOracle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wonda\DEMOUNI\resources\views\data.blade.php ENDPATH**/ ?>