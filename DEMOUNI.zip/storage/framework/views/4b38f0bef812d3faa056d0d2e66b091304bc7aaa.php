

<?php $__env->startSection('content'); ?> 
<section class="section-content my-3 "> 
    <div class="d-flex justify-content-center ">
        <div class="row">           
            <div class="card col-xl-12">
                <article class="card-body">
                <form id="f_ta" method="POST" action="<?php echo e(route('update.task')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
                <div class="form-group">
                    <label>Assignee </label>
                    <select name="assignee" class="form-control" type="text">
                    <option value="<?php echo e($d->assignee); ?>" class="text-info" selected><?php echo e($d->assignee); ?></option>
                    <?php $__currentLoopData = \App\Models\Team::get(['id', 'username']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($team->id); ?>" class="text-info"><?php echo e($team->username); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </select>               
                </div> <!-- form-group// -->
                <div class="form-group">
                    <label>Name</label>
                    <input name="name" class="form-control" type="text" value="<?php echo e($d->name); ?>">               
                </div> <!-- form-group// -->
                <div class="form-group">
                    <label>Description</label>
                    <input name="description" class="form-control" type="text" value="<?php echo e($d->description); ?>">               
                </div> <!-- form-group// -->
                <div class="form-group">
                    <label>Project</label>
                    <select name="project_id" class="form-control" type="text">
                    <option value="<?php echo e($d->project_id); ?>" class="text-info" selected><?php echo e($d->project_id); ?></option>
                <?php $__currentLoopData = \App\Models\Project::get(['id', 'name']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" class="text-info"><?php echo e($p->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>
                </div> <!-- form-group// -->  
                <div class="form-group">
                    <label>Milestone</label>
                    <select name="milestone_id" class="form-control" type="text">
                    <option value="<?php echo e($d->milestone_id); ?>" class="text-info" selected><?php echo e($d->milestone_id); ?></option>
                <?php $__currentLoopData = \App\Models\Milestone::get(['id', 'name']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" class="text-info"><?php echo e($p->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>
                </div> <!-- form-group// --> 
                <div class="form-group">
                    <label>Is complete</label>
                    <select name="is_complete_yn" class="form-control" type="text">
                    <option value="<?php echo e($d->is_complete_yn); ?>" class="text-info" selected><?php echo e($d->is_complete_yn); ?></option>
                        <option value="Y" class="text-info">YES</option>
                        <option value="N" class="text-info">NO</option>
                    </select>
                </div> <!-- form-group// -->   
                <div class="form-group">
                    <label>Start date</label>
                        <?php 
                            $date=date_format(date_create($d->start_date),'Y-m-d');
                        ?>
                    <input name="start_date" class="form-control" type="date" value="<?php echo e($date); ?>">               
                </div> <!-- form-group// -->  
                <div class="form-group">
                    <label>End date</label>
                        <?php 
                            $date=date_format(date_create($d->end_date),'Y-m-d');
                        ?>
                    <input name="end_date" class="form-control" type="date" value="<?php echo e($date); ?>">               
                </div> <!-- form-group// -->        
                <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-block my-1"> Update  </button>
                </div> <!-- form-group// -->                                                           
            </form>                 
                </article> <!--card body-->
            </div> <!--end card-->
        </div> <!--end row-->
    </div> <!--container-->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wonda\DEMOUNI\resources\views\update_task.blade.php ENDPATH**/ ?>