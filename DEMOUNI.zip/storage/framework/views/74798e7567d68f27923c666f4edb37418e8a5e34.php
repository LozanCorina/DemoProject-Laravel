<?php $__env->startSection('content'); ?>
    <section class="section-content my-3 ">
        <div class="d-flex justify-content-center ">
            <div class="row">
                <div class="card col-xl-12">
                    <article class="card-body">
                        <form id="f_p" method="POST" action="<?php echo e(route('data','Project')); ?>" >
                            <?php echo csrf_field(); ?>
                            <?php while(($d = oci_fetch_object($stid)) != false): ?>
                            <input type="hidden" name="id" value="<?php echo e($d->ID); ?>">
                            <div class="form-group">
                                <label>Name</label>
                                <input name="name" class="form-control" type="text" value="<?php echo e($d->NAME); ?>">
                            </div> <!-- form-group// -->
                            <div class="form-group">
                                <label>Description</label>
                                <input name="description" class="form-control" type="text" value="<?php echo e($d->DESCRIPTION); ?>">
                            </div> <!-- form-group// -->
                            <div class="form-group">
                                <label>Project Lead</label>
                                <select name="project_lead" class="form-control" type="text" >
                                    <option value="<?php echo e($d->PROJECT_LEAD); ?>" class="text-info" selected><?php echo e($d->PROJECT_LEAD); ?></option>
                                    <?php
                                        $st = oci_parse($conn, 'SELECT id, username FROM demo_team_members ');
                                        oci_execute($st);
                                    ?>
                                    <?php while(($team = oci_fetch_object($st)) != false): ?>
                                        <option value="<?php echo e($team->ID); ?>" class="text-info"><?php echo e($team->USERNAME); ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div> <!-- form-group// -->
                            <div class="form-group">
                                <label>Completed date</label>
                                <?php
                                    $date=date_format(date_create($d->COMPLETED_DATE),'Y-m-d');
                                ?>
                                <input name="completed_date" class="form-control" type="date" value="<?php echo e($date); ?>">
                            </div> <!-- form-group// -->
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control" type="text" >
                                    <option value="<?php echo e($d->STATUS); ?>" class="text-info" selected><?php echo e($d->STATUS); ?></option>
                                    <option value="Completed" class="text-info">Completed</option>
                                    <option value="Assigned" class="text-info">Assigned</option>
                                    <option value=" In-Progress" class="text-info"> In-Progress</option>
                                </select>
                            </div> <!-- form-group// -->
                            <?php endwhile; ?>
                            <?php
                                oci_free_statement($stid);
                                oci_close($conn);
                            ?>

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block my-1"> Update  </button>
                            </div> <!-- form-group// -->
                        </form>
                    </article> <!--card body-->
                </div> <!--end card-->
            </div> <!--end row-->
        </div> <!--container-->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.headerOracle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wonda\DEMOUNI\resources\views\oracle\update_project.blade.php ENDPATH**/ ?>